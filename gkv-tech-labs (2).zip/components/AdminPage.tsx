import React, { useState, useCallback, useEffect } from 'react';
import { useLabData } from '../App';
import { ADMIN_USERNAME, ADMIN_PASSWORD } from '../constants';
import { Branch, Semester, LabSubject, Experiment } from '../types';
import { Modal, LoadingSpinner, ConfirmationModal } from './common';
import { generateExperimentSummary } from '../services/geminiService';
import { PlusCircle, Edit, Trash2, GraduationCap, Layers, BookOpen, FlaskConical } from 'lucide-react';

// --- LOGIN COMPONENT ---
const AdminLogin: React.FC = () => {
  const { login } = useLabData();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      setError('');
      login();
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-xl">
        <h2 className="text-3xl font-extrabold text-center text-indigo-900">Admin Login</h2>
        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-4 rounded-md shadow-sm">
            <div>
              <label htmlFor="username" className="sr-only">Username</label>
              <input id="username" name="username" type="text" required value={username} onChange={e => setUsername(e.target.value)}
                className="relative block w-full px-3 py-3 text-lg border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10"
                placeholder="Username" />
            </div>
            <div>
              <label htmlFor="password-admin" className="sr-only">Password</label>
              <input id="password-admin" name="password" type="password" required value={password} onChange={e => setPassword(e.target.value)}
                className="relative block w-full px-3 py-3 text-lg border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10"
                placeholder="Password" />
            </div>
          </div>
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}
          <div>
            <button type="submit" className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-lg font-medium rounded-md text-white bg-indigo-700 hover:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
              Sign in
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};


// --- CRUD Operations Type Definitions ---
type CrudOperation = 'add' | 'edit';
type DataType = 'branch' | 'semester' | 'subject' | 'experiment';
interface ModalState {
  isOpen: boolean;
  operation?: CrudOperation;
  type?: DataType;
  data?: any;
  parentId?: string; // e.g., branchId when adding a semester
  grandParentId?: string; // e.g., branchId when adding a subject
  greatGrandParentId?: string; // e.g., branchId for experiment
}

// --- ADMIN DASHBOARD ---
const AdminDashboard: React.FC = () => {
    const { labData, setLabData } = useLabData();
    const [modalState, setModalState] = useState<ModalState>({ isOpen: false });
    const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({});
    
    interface DeleteConfirmState {
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
    }
    const [deleteConfirmState, setDeleteConfirmState] = useState<DeleteConfirmState>({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => {},
    });

    const toggleExpand = (id: string) => {
        setExpandedIds(prev => ({...prev, [id]: !prev[id]}));
    };
    
    const handleOpenModal = (operation: CrudOperation, type: DataType, data?: any, parentId?: string, grandParentId?: string, greatGrandParentId?: string) => {
        setModalState({ isOpen: true, operation, type, data, parentId, grandParentId, greatGrandParentId });
    };

    const handleDelete = (type: DataType, id: string, parentId?: string, grandParentId?: string, greatGrandParentId?: string) => {
        const onConfirm = () => {
            setLabData(prevData => {
                const newData = JSON.parse(JSON.stringify(prevData));
                if (type === 'branch') {
                    return newData.filter((b: Branch) => b.id !== id);
                }
                if (type === 'semester' && parentId) {
                    const branch = newData.find((b: Branch) => b.id === parentId);
                    if (branch) branch.semesters = branch.semesters.filter((s: Semester) => s.id !== id);
                }
                if (type === 'subject' && parentId && grandParentId) {
                    const branch = newData.find((b: Branch) => b.id === grandParentId);
                    const semester = branch?.semesters.find((s: Semester) => s.id === parentId);
                    if (semester) semester.subjects = semester.subjects.filter((sub: LabSubject) => sub.id !== id);
                }
                if (type === 'experiment' && parentId && grandParentId && greatGrandParentId) {
                    const branch = newData.find((b: Branch) => b.id === greatGrandParentId);
                    const semester = branch?.semesters.find((s: Semester) => s.id === grandParentId);
                    const subject = semester?.subjects.find((sub: LabSubject) => sub.id === parentId);
                    if (subject) subject.experiments = subject.experiments.filter((exp: Experiment) => exp.id !== id);
                }
                return newData;
            });
        };
        
        setDeleteConfirmState({
            isOpen: true,
            title: `Delete ${type}`,
            message: `Are you sure you want to delete this ${type}? This action is permanent and will remove all nested items.`,
            onConfirm,
        });
    };

    const handleSave = (type: DataType, data: any, operation: CrudOperation, parentId?: string, grandParentId?: string, greatGrandParentId?: string) => {
        setLabData(prevData => {
            const newData = JSON.parse(JSON.stringify(prevData));
            const newItem = operation === 'add' ? { ...data, id: Date.now().toString() } : data;

            if (type === 'branch') {
                if (operation === 'add') newData.push({ ...newItem, semesters: [] });
                else {
                    const index = newData.findIndex((b: Branch) => b.id === newItem.id);
                    if (index !== -1) newData[index] = { ...newData[index], ...newItem };
                }
            } else if (type === 'semester' && parentId) {
                const branch = newData.find((b: Branch) => b.id === parentId);
                if (operation === 'add') branch.semesters.push({ ...newItem, subjects: [] });
                else {
                    const index = branch.semesters.findIndex((s: Semester) => s.id === newItem.id);
                    if (index !== -1) branch.semesters[index] = { ...branch.semesters[index], ...newItem };
                }
            } else if (type === 'subject' && parentId && grandParentId) {
                const branch = newData.find((b: Branch) => b.id === grandParentId);
                const semester = branch?.semesters.find((s: Semester) => s.id === parentId);
                if (operation === 'add') semester.subjects.push({ ...newItem, experiments: [] });
                else {
                    const index = semester.subjects.findIndex((sub: LabSubject) => sub.id === newItem.id);
                    if (index !== -1) semester.subjects[index] = { ...semester.subjects[index], ...newItem };
                }
            } else if (type === 'experiment' && parentId && grandParentId && greatGrandParentId) {
                const branch = newData.find((b: Branch) => b.id === greatGrandParentId);
                const semester = branch?.semesters.find((s: Semester) => s.id === grandParentId);
                const subject = semester?.subjects.find((sub: LabSubject) => sub.id === parentId);
                if (operation === 'add') subject.experiments.push(newItem);
                else {
                    const index = subject.experiments.findIndex((exp: Experiment) => exp.id === newItem.id);
                    if (index !== -1) subject.experiments[index] = newItem;
                }
            }

            return newData;
        });
        setModalState({ isOpen: false });
    };

    const renderItem = (Icon: React.ElementType, title: string, onEdit: () => void, onDelete: () => void) => (
        <div className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm border">
            <div className="flex items-center space-x-3">
                <Icon className="w-5 h-5 text-indigo-600" />
                <span className="font-medium text-slate-700">{title}</span>
            </div>
            <div className="flex items-center space-x-2">
                <button onClick={onEdit} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-blue-100 text-blue-800 hover:bg-blue-200 font-semibold transition-colors" aria-label={`Edit ${title}`}>
                    <Edit size={16} /> Edit
                </button>
                <button onClick={onDelete} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-red-100 text-red-800 hover:bg-red-200 font-semibold transition-colors" aria-label={`Delete ${title}`}>
                    <Trash2 size={16} /> Delete
                </button>
            </div>
        </div>
    );
    
    return (
        <div className="container mx-auto">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-extrabold text-indigo-900">Admin Dashboard</h1>
                <button onClick={() => handleOpenModal('add', 'branch')} className="flex items-center gap-2 px-4 py-2 bg-indigo-700 text-white font-semibold rounded-md shadow-sm hover:bg-indigo-800 transition-all">
                    <PlusCircle size={20} /> Add Branch
                </button>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg space-y-4">
                {labData.map(branch => (
                    <div key={branch.id} className="p-4 border border-slate-200 rounded-lg bg-slate-50/50">
                        <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpand(branch.id)}>
                             <div className="flex items-center gap-3">
                                <GraduationCap className="w-6 h-6 text-indigo-700" />
                                <h2 className="text-xl font-bold text-slate-800">{branch.name}</h2>
                            </div>
                            <div className="flex items-center space-x-2">
                               <button onClick={(e) => { e.stopPropagation(); handleOpenModal('add', 'semester', undefined, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-green-100 text-green-800 hover:bg-green-200 font-semibold transition-colors"><PlusCircle size={16}/> Add Semester</button>
                               <button onClick={(e) => { e.stopPropagation(); handleOpenModal('edit', 'branch', branch); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-blue-100 text-blue-800 hover:bg-blue-200 font-semibold transition-colors" aria-label={`Edit Branch ${branch.name}`}><Edit size={16} /> Edit</button>
                               <button onClick={(e) => { e.stopPropagation(); handleDelete('branch', branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-red-100 text-red-800 hover:bg-red-200 font-semibold transition-colors" aria-label={`Delete Branch ${branch.name}`}><Trash2 size={16} /> Delete</button>
                            </div>
                        </div>

                        {expandedIds[branch.id] && <div className="pl-8 pt-4 space-y-3">
                            {branch.semesters.map(semester => (
                                <div key={semester.id} className="p-3 border-l-4 border-indigo-200 bg-white">
                                    <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpand(semester.id)}>
                                        <div className="flex items-center gap-3">
                                            <Layers className="w-5 h-5 text-indigo-600" />
                                            <h3 className="font-semibold text-lg text-slate-700">Semester {semester.number}</h3>
                                        </div>
                                         <div className="flex items-center space-x-2">
                                            <button onClick={(e) => { e.stopPropagation(); handleOpenModal('add', 'subject', undefined, semester.id, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-green-100 text-green-800 hover:bg-green-200 font-semibold transition-colors"><PlusCircle size={16}/> Add Subject</button>
                                            <button onClick={(e) => { e.stopPropagation(); handleOpenModal('edit', 'semester', semester, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-blue-100 text-blue-800 hover:bg-blue-200 font-semibold transition-colors" aria-label={`Edit Semester ${semester.number}`}><Edit size={16} /> Edit</button>
                                            <button onClick={(e) => { e.stopPropagation(); handleDelete('semester', semester.id, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-red-100 text-red-800 hover:bg-red-200 font-semibold transition-colors" aria-label={`Delete Semester ${semester.number}`}><Trash2 size={16} /> Delete</button>
                                        </div>
                                    </div>
                                    {expandedIds[semester.id] && <div className="pl-8 pt-3 space-y-2">
                                        {semester.subjects.map(subject => (
                                            <div key={subject.id} className="p-3 border-l-4 border-green-200 bg-white">
                                                <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleExpand(subject.id)}>
                                                    <div className="flex items-center gap-3">
                                                        <BookOpen className="w-5 h-5 text-green-600" />
                                                        <h4 className="font-medium text-md">{subject.name}</h4>
                                                    </div>
                                                    <div className="flex items-center space-x-2">
                                                        <button onClick={(e) => { e.stopPropagation(); handleOpenModal('add', 'experiment', undefined, subject.id, semester.id, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-green-100 text-green-800 hover:bg-green-200 font-semibold transition-colors"><PlusCircle size={16}/> Add Experiment</button>
                                                        <button onClick={(e) => { e.stopPropagation(); handleOpenModal('edit', 'subject', subject, semester.id, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-blue-100 text-blue-800 hover:bg-blue-200 font-semibold transition-colors" aria-label={`Edit Subject ${subject.name}`}><Edit size={16} /> Edit</button>
                                                        <button onClick={(e) => { e.stopPropagation(); handleDelete('subject', subject.id, semester.id, branch.id); }} className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-md bg-red-100 text-red-800 hover:bg-red-200 font-semibold transition-colors" aria-label={`Delete Subject ${subject.name}`}><Trash2 size={16} /> Delete</button>
                                                    </div>
                                                </div>
                                                {expandedIds[subject.id] && <div className="pl-8 pt-3 space-y-2">
                                                    {subject.experiments.map(exp => (
                                                        <div key={exp.id}>{renderItem(FlaskConical, exp.name,
                                                            () => handleOpenModal('edit', 'experiment', exp, subject.id, semester.id, branch.id),
                                                            () => handleDelete('experiment', exp.id, subject.id, semester.id, branch.id)
                                                        )}</div>
                                                    ))}
                                                </div>}
                                            </div>
                                        ))}
                                    </div>}
                                </div>
                            ))}
                        </div>}
                    </div>
                ))}
            </div>
            <ConfirmationModal
                isOpen={deleteConfirmState.isOpen}
                onClose={() => setDeleteConfirmState({ ...deleteConfirmState, isOpen: false })}
                onConfirm={deleteConfirmState.onConfirm}
                title={deleteConfirmState.title}
                message={deleteConfirmState.message}
            />
            <DataForm {...modalState} onClose={() => setModalState({ isOpen: false })} onSave={handleSave} />
        </div>
    );
};

// --- DATA FORM for Modal ---
interface DataFormProps extends ModalState {
    onClose: () => void;
    onSave: (type: DataType, data: any, operation: CrudOperation, parentId?: string, grandParentId?: string, greatGrandParentId?: string) => void;
}

const DataForm: React.FC<DataFormProps> = ({ isOpen, operation, type, data, parentId, grandParentId, greatGrandParentId, onClose, onSave }) => {
    const [formData, setFormData] = useState<any>({});
    const [isGenerating, setIsGenerating] = useState(false);
    const { labData } = useLabData();

    useEffect(() => {
        if (isOpen) { // Only change formData when modal opens
            setFormData(data || {});
        }
    }, [data, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData((prev: any) => ({ ...prev, [name]: value }));
    };


    const handleGenerateSummary = async () => {
        if (!greatGrandParentId || !grandParentId || !formData.name) {
            alert("Please provide Experiment Name, Branch, and Semester to generate a summary.");
            return;
        }

        const branch = labData.find(b => b.id === greatGrandParentId);
        const semester = branch?.semesters.find(s => s.id === grandParentId);

        if (!branch || !semester) return;
        
        setIsGenerating(true);
        try {
            const summary = await generateExperimentSummary(formData.name, branch.name, semester.number);
            setFormData((prev: any) => ({ ...prev, summary: summary }));
        } catch (error) {
            console.error(error);
        } finally {
            setIsGenerating(false);
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (type && operation) {
            onSave(type, formData, operation, parentId, grandParentId, greatGrandParentId);
        }
    };

    const renderFormFields = () => {
        switch (type) {
            case 'branch':
                return <InputField name="name" label="Branch Name" value={formData.name || ''} onChange={handleChange} />;
            case 'semester':
                return <InputField name="number" label="Semester Number" type="number" value={formData.number || ''} onChange={handleChange} />;
            case 'subject':
                return <InputField name="name" label="Subject Name" value={formData.name || ''} onChange={handleChange} />;
            case 'experiment':
                return (
                    <>
                        <InputField name="name" label="Experiment Name" value={formData.name || ''} onChange={handleChange} />
                        <div className="relative">
                           <TextAreaField name="summary" label="Summary" value={formData.summary || ''} onChange={handleChange} rows={3}/>
                           <button type="button" onClick={handleGenerateSummary} disabled={isGenerating || !process.env.API_KEY} className="absolute top-0 right-0 mt-1 mr-1 px-2 py-1 text-xs font-semibold text-white bg-indigo-600 rounded disabled:bg-slate-400 hover:bg-indigo-700 transition-colors">
                                {isGenerating ? <LoadingSpinner size="sm" /> : 'Generate with AI'}
                            </button>
                        </div>
                        <TextAreaField name="description" label="Description" value={formData.description || ''} onChange={handleChange} rows={5}/>
                        <InputField name="reportUrl" label="Report PDF URL" value={formData.reportUrl || ''} onChange={handleChange} />
                        <InputField name="videoUrl" label="Practical Video URL" value={formData.videoUrl || ''} onChange={handleChange} />
                    </>
                );
            default:
                return null;
        }
    };
    
    if (!isOpen || !type || !operation) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`${operation === 'add' ? 'Add' : 'Edit'} ${type}`}>
            <form onSubmit={handleSubmit} className="space-y-4">
                {renderFormFields()}
                <div className="flex justify-end gap-4 pt-4">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">Cancel</button>
                    <button type="submit" className="px-4 py-2 text-sm font-semibold text-white bg-indigo-700 rounded-md hover:bg-indigo-800">Save Changes</button>
                </div>
            </form>
        </Modal>
    );
};

const InputField: React.FC<{name: string, label: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, type?: string}> = ({ name, label, value, onChange, type = 'text' }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input type={type} id={name} name={name} value={value} onChange={onChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"/>
    </div>
);

const TextAreaField: React.FC<{name: string, label: string, value: string, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void, rows?: number}> = ({ name, label, value, onChange, rows=3 }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <textarea id={name} name={name} value={value} onChange={onChange} rows={rows} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"></textarea>
    </div>
);


// --- MAIN ADMIN PAGE WRAPPER ---
export const AdminPage: React.FC = () => {
  const { isLoggedIn } = useLabData();
  return isLoggedIn ? <AdminDashboard /> : <AdminLogin />;
};