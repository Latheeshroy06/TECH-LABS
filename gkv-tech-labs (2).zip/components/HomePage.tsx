import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLabData } from '../App';
import { Branch, Semester, LabSubject, Experiment } from '../types';
import { Breadcrumbs } from './common';
import { FileText, Video, ChevronsRight, BookOpen, Layers, GraduationCap, Share2 } from 'lucide-react';


export const HomePage: React.FC = () => {
  const { labData } = useLabData();
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  const [selectedSemester, setSelectedSemester] = useState<Semester | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<LabSubject | null>(null);
  const [selectedExperiment, setSelectedExperiment] = useState<Experiment | null>(null);

  const params = useParams<{ branchId: string; semesterId: string; subjectId: string; experimentId: string; }>();
  const navigate = useNavigate();

  useEffect(() => {
    const { branchId, semesterId, subjectId, experimentId } = params;
    if (branchId && semesterId && subjectId && experimentId && labData.length > 0) {
        const branch = labData.find(b => b.id === branchId);
        const semester = branch?.semesters.find(s => s.id === semesterId);
        const subject = semester?.subjects.find(sub => sub.id === subjectId);
        const experiment = subject?.experiments.find(exp => exp.id === experimentId);

        if (branch && semester && subject && experiment) {
            setSelectedBranch(branch);
            setSelectedSemester(semester);
            setSelectedSubject(subject);
            setSelectedExperiment(experiment);
        } else {
            // If link is invalid, go to home
            navigate('/');
        }
    }
  }, [params, labData, navigate]);

  const resetTo = (level: 'root' | 'branch' | 'semester' | 'subject') => {
    setSelectedExperiment(null);
    if (level === 'root' || level === 'branch' || level === 'semester') setSelectedSubject(null);
    if (level === 'root' || level === 'branch') setSelectedSemester(null);
    if (level === 'root') setSelectedBranch(null);
    // When using breadcrumbs to go back, reset the URL to the root
    if (window.location.hash !== '#/') {
        navigate('/');
    }
  };

  const handleSelectExperiment = (experiment: Experiment) => {
      setSelectedExperiment(experiment);
      if (selectedBranch && selectedSemester && selectedSubject) {
          navigate(`/experiment/${selectedBranch.id}/${selectedSemester.id}/${selectedSubject.id}/${experiment.id}`, { replace: true });
      }
  };
  
  const breadcrumbItems = [
    { label: 'Branches', onClick: () => resetTo('root') },
    ...(selectedBranch ? [{ label: selectedBranch.name, onClick: () => resetTo('branch') }] : []),
    ...(selectedSemester ? [{ label: `Semester ${selectedSemester.number}`, onClick: () => resetTo('semester') }] : []),
    ...(selectedSubject ? [{ label: selectedSubject.name, onClick: () => resetTo('subject') }] : []),
    ...(selectedExperiment ? [{ label: selectedExperiment.name }] : []),
  ];

  const renderContent = () => {
    if (selectedExperiment) return <ExperimentDetails experiment={selectedExperiment} />;
    if (selectedSubject) return <ExperimentList subject={selectedSubject} onSelect={handleSelectExperiment} />;
    if (selectedSemester) return <SubjectList semester={selectedSemester} onSelect={setSelectedSubject} />;
    if (selectedBranch) return <SemesterList branch={selectedBranch} onSelect={setSelectedSemester} />;
    return <BranchList branches={labData} onSelect={setSelectedBranch} />;
  };

  return (
    <div className="container mx-auto">
      <Breadcrumbs items={breadcrumbItems} />
      <div className="bg-white rounded-xl shadow-lg p-6 min-h-[60vh]">
        {renderContent()}
      </div>
    </div>
  );
};

const Card: React.FC<{ title: string; onClick: () => void; icon: React.ReactNode; count: number, countLabel: string }> = ({ title, onClick, icon, count, countLabel }) => (
    <div onClick={onClick} className="bg-slate-50 rounded-lg p-6 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-slate-200 group">
        <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
                <div className="bg-indigo-100 text-indigo-700 p-3 rounded-full">
                    {icon}
                </div>
                <div>
                    <h3 className="text-lg font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{title}</h3>
                    <p className="text-sm text-slate-500">{count} {countLabel}</p>
                </div>
            </div>
            <ChevronsRight className="w-6 h-6 text-indigo-400 group-hover:text-indigo-600 transition-colors" />
        </div>
    </div>
);


const BranchList: React.FC<{ branches: Branch[]; onSelect: (branch: Branch) => void }> = ({ branches, onSelect }) => (
    <div>
        <h2 className="text-3xl font-extrabold text-indigo-900 mb-6">Select a Branch</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {branches.map(b => <Card key={b.id} title={b.name} onClick={() => onSelect(b)} icon={<GraduationCap />} count={b.semesters.length} countLabel="semesters" />)}
        </div>
    </div>
);

const SemesterList: React.FC<{ branch: Branch; onSelect: (semester: Semester) => void }> = ({ branch, onSelect }) => (
    <div>
        <h2 className="text-3xl font-extrabold text-indigo-900 mb-6">{branch.name}</h2>
        <h3 className="text-xl font-semibold text-slate-600 mb-6">Select a Semester</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {branch.semesters.length > 0 ? branch.semesters.map(s => <Card key={s.id} title={`Semester ${s.number}`} onClick={() => onSelect(s)} icon={<Layers />} count={s.subjects.length} countLabel="subjects"/>) : <p className="text-slate-500">No semesters added yet.</p>}
        </div>
    </div>
);

const SubjectList: React.FC<{ semester: Semester; onSelect: (subject: LabSubject) => void }> = ({ semester, onSelect }) => (
     <div>
        <h2 className="text-3xl font-extrabold text-indigo-900 mb-6">Semester {semester.number}</h2>
        <h3 className="text-xl font-semibold text-slate-600 mb-6">Select a Lab Subject</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {semester.subjects.length > 0 ? semester.subjects.map(sub => <Card key={sub.id} title={sub.name} onClick={() => onSelect(sub)} icon={<BookOpen />} count={sub.experiments.length} countLabel="experiments"/>) : <p className="text-slate-500">No subjects added yet.</p>}
        </div>
    </div>
);

const ExperimentList: React.FC<{ subject: LabSubject; onSelect: (experiment: Experiment) => void }> = ({ subject, onSelect }) => (
    <div>
        <h2 className="text-3xl font-extrabold text-indigo-900 mb-6">{subject.name}</h2>
        <h3 className="text-xl font-semibold text-slate-600 mb-6">Select an Experiment</h3>
        <ul className="space-y-3">
            {subject.experiments.length > 0 ? subject.experiments.map(exp => (
                <li key={exp.id} onClick={() => onSelect(exp)} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-indigo-50 transition-colors cursor-pointer border">
                    <span className="font-medium text-slate-700">{exp.name}</span>
                    <ChevronsRight className="w-5 h-5 text-indigo-500"/>
                </li>
            )) : <p className="text-slate-500">No experiments added yet.</p>}
        </ul>
    </div>
);

const ExperimentDetails: React.FC<{ experiment: Experiment }> = ({ experiment }) => {
    const [isCopied, setIsCopied] = useState(false);

    const handleShare = () => {
      navigator.clipboard.writeText(window.location.href).then(() => {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2500);
      }, (err) => {
        console.error('Could not copy link: ', err);
        alert('Failed to copy link.');
      });
    };

    return (
        <div className="animate-fade-in">
            <h2 className="text-3xl font-extrabold text-indigo-900 mb-2">{experiment.name}</h2>
            <div className="space-y-8 mt-6">
                <div>
                    <h3 className="text-xl font-bold text-slate-700 border-b-2 border-indigo-200 pb-2 mb-3">Summary</h3>
                    <p className="text-slate-600 leading-relaxed">{experiment.summary}</p>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-slate-700 border-b-2 border-indigo-200 pb-2 mb-3">Description</h3>
                    <p className="text-slate-600 leading-relaxed">{experiment.description}</p>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-slate-700 border-b-2 border-indigo-200 pb-2 mb-3">Resources</h3>
                    <div className="flex flex-col sm:flex-row flex-wrap gap-4 mt-4">
                        <a href={experiment.reportUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-all transform hover:scale-105">
                            <FileText size={20} />
                            View Report (PDF)
                        </a>
                        <a href={experiment.videoUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 bg-red-600 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 transition-all transform hover:scale-105">
                            <Video size={20} />
                            Watch Practical Video
                        </a>
                         <button
                            onClick={handleShare}
                            disabled={isCopied}
                            className="flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 transition-all transform hover:scale-105 disabled:bg-green-400 disabled:scale-100 disabled:cursor-not-allowed"
                            >
                            <Share2 size={20} />
                            {isCopied ? 'Link Copied!' : 'Share Link'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
};