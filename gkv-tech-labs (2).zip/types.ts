export interface Experiment {
  id: string;
  name: string;
  summary: string;
  description: string;
  reportUrl: string; // URL to PDF
  videoUrl: string; // URL to video
}

export interface LabSubject {
  id: string;
  name: string;
  experiments: Experiment[];
}

export interface Semester {
  id: string;
  number: number;
  subjects: LabSubject[];
}

export interface Branch {
  id: string;
  name: string;
  semesters: Semester[];
}