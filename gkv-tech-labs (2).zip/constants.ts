import { Branch } from './types';

export const ADMIN_USERNAME = 'GKV';
export const ADMIN_PASSWORD = 'labs';

export const INITIAL_DATA: Branch[] = [
  {
    id: 'cse',
    name: 'Computer Science & Engineering',
    semesters: [
      {
        id: 'cse_sem3',
        number: 3,
        subjects: [
          {
            id: 'cse_sem3_ds',
            name: 'Data Structures Lab',
            experiments: [
              {
                id: 'exp1',
                name: 'Implement Stack using Array',
                summary: 'This experiment focuses on the implementation of a stack data structure using a static array. Key operations like push, pop, peek, and isEmpty are implemented and tested.',
                description: 'A stack is a linear data structure that follows the LIFO (Last-In, First-Out) principle. This implementation uses a fixed-size array to store elements. We will explore the challenges of overflow and underflow conditions.',
                reportUrl: 'https://www.africau.edu/images/default/sample.pdf',
                videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
              },
               {
                id: 'exp2',
                name: 'Implement Queue using Linked List',
                summary: 'This experiment involves creating a dynamic queue data structure using a linked list. Operations such as enqueue, dequeue, and peek will be implemented.',
                description: 'Unlike array-based queues, a linked-list implementation allows for a dynamic size, avoiding the issue of overflow. This experiment covers pointer manipulation and memory management for nodes.',
                reportUrl: 'https://www.africau.edu/images/default/sample.pdf',
                videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'ece',
    name: 'Electronics & Communication Engg.',
    semesters: []
  },
  {
    id: 'me',
    name: 'Mechanical Engineering',
    semesters: []
  },
  {
    id: 'ee',
    name: 'Electrical Engineering',
    semesters: []
  }
];