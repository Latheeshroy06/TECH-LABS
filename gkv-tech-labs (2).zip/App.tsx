import React, { useState, useCallback, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Link } from 'react-router-dom';
import { HomePage } from './components/HomePage';
import { AdminPage } from './components/AdminPage';
import { Logo } from './components/common';
import { Branch } from './types';
import { INITIAL_DATA } from './constants';

// Data Context
interface LabDataContextType {
  labData: Branch[];
  setLabData: React.Dispatch<React.SetStateAction<Branch[]>>;
  isLoggedIn: boolean;
  login: () => void;
  logout: () => void;
}

const LabDataContext = createContext<LabDataContextType | null>(null);

export const useLabData = () => {
  const context = useContext(LabDataContext);
  if (!context) {
    throw new Error('useLabData must be used within a LabDataProvider');
  }
  return context;
};

// App Component
const App: React.FC = () => {
  const [labData, setLabData] = useState<Branch[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    try {
      const storedData = localStorage.getItem('gkvTechLabsData');
      const storedAuth = localStorage.getItem('gkvTechLabsAuth') === 'true';
      if (storedData) {
        setLabData(JSON.parse(storedData));
      } else {
        setLabData(INITIAL_DATA);
      }
      setIsLoggedIn(storedAuth);
    } catch (error) {
      console.error("Failed to load data from localStorage", error);
      setLabData(INITIAL_DATA);
    } finally {
        setIsInitialized(true);
    }
  }, []);

  useEffect(() => {
    if (isInitialized) {
        try {
            localStorage.setItem('gkvTechLabsData', JSON.stringify(labData));
        } catch (error) {
            console.error("Failed to save data to localStorage", error);
        }
    }
  }, [labData, isInitialized]);
  
  useEffect(() => {
      if(isInitialized) {
        localStorage.setItem('gkvTechLabsAuth', String(isLoggedIn));
      }
  }, [isLoggedIn, isInitialized]);


  const login = useCallback(() => setIsLoggedIn(true), []);
  const logout = useCallback(() => setIsLoggedIn(false), []);

  if (!isInitialized) {
      return (
         <div className="flex items-center justify-center h-screen bg-pink-100">
            <div className="text-center">
                <Logo className="h-20 w-20 mx-auto animate-pulse" />
                <h1 className="text-2xl font-bold text-indigo-900 mt-4">Loading GKV Tech Labs...</h1>
            </div>
        </div>
      );
  }

  return (
    <LabDataContext.Provider value={{ labData, setLabData, isLoggedIn, login, logout }}>
      <HashRouter>
        <div className="min-h-screen bg-gradient-to-br from-pink-50 to-rose-200 text-slate-800">
          <Header />
          <main className="p-4 sm:p-6 lg:p-8">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/experiment/:branchId/:semesterId/:subjectId/:experimentId" element={<HomePage />} />
              <Route path="/admin" element={<AdminPage />} />
            </Routes>
          </main>
        </div>
      </HashRouter>
    </LabDataContext.Provider>
  );
};

const Header: React.FC = () => {
  const { isLoggedIn, logout } = useLabData();

  return (
    <header className="bg-white/70 backdrop-blur-lg sticky top-0 z-40 shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center space-x-3 group">
            <Logo className="h-12 w-12 text-indigo-800 group-hover:text-indigo-600 transition-colors" />
            <span className="text-xl sm:text-2xl font-extrabold text-indigo-900 tracking-tight group-hover:text-indigo-700 transition-colors">
              GKV TECH LABS
            </span>
          </Link>
          <nav>
            {isLoggedIn ? (
              <button
                onClick={logout}
                className="px-4 py-2 text-sm font-semibold text-white bg-red-600 rounded-md shadow-sm hover:bg-red-700 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Logout Admin
              </button>
            ) : (
              <Link
                to="/admin"
                className="px-4 py-2 text-sm font-semibold text-white bg-indigo-700 rounded-md shadow-sm hover:bg-indigo-800 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Admin Panel
              </Link>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default App;