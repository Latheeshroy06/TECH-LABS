import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const generateExperimentSummary = async (experimentName: string, branchName: string, semester: number): Promise<string> => {
  if (!process.env.API_KEY) {
    return "AI service is not available. Please set the API_KEY environment variable.";
  }
  
  try {
    const prompt = `Generate a concise, professional summary for a university lab experiment.
    
    Experiment Title: "${experimentName}"
    Branch: ${branchName}
    Semester: ${semester}
    
    The summary should be about 50-70 words, explaining the core objective and key concepts of the experiment. Do not use markdown.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 1,
        topK: 32,
        maxOutputTokens: 150,
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text;
  } catch (error) {
    console.error("Error generating summary with Gemini:", error);
    return "Failed to generate summary. Please try again or write one manually.";
  }
};